package jandl;

import jandl.wizard.Data;
import jandl.wizard.WizardBase;
import jandl.wizard.WizardFactory;
import jandl.wizard.WizardText;
import java.util.Arrays;
import javax.swing.SwingUtilities;

public class Quiz {

    public static void main(String[] args) throws Exception {
        //Tela01
        WizardBase tela1 = WizardFactory.createBase("Quiz");
        tela1.setImage("!/resources/quiz.png");
        //Tela02
        String[] opcoes1 = {"A)Branco", "B)Marrom", "C)Preto","D)Nenhuma das opções"};
		WizardBase tela2 = WizardFactory.createList("Pagina 04", "opt", "1)Qual a cor do cavalo branco de Napoleão?", opcoes1);
        //Tela03
        String[] opcoes2 = {"A)Sistema operacional para desenvolvimento", "B)É uma linguagem de programação, um ambiente de desenvolvivento e um ambiente de aplicação", "C)É uma IDE para desenvolvimento e de software","D)Nenhuma das opções"};
		WizardBase tela3 = WizardFactory.createList("Pagina 04", "opt", "2)O que é o Java?", opcoes2);
        //Tela04
        String[] opcoes3 = {"A)Um número qualquer", "B)Mundial do Palmeiras", "C)Área 51","D)Pinga"};
		WizardBase tela4 = WizardFactory.createList("Pagina 04", "opt", "3)51 é o que?", opcoes3);
        //Tela05
        String[] opcoes4 = {"A)Corinthians", "B)Ponte Preta", "C)Água Santa","D)Time do bairro"};
		WizardBase tela5 = WizardFactory.createList("Pagina 04", "opt", "4)Qual é o maior time do Brasil?", opcoes4);
        //Tela06
        String[] opcoes5 = {"A)Mãe", "B)Pai", "C)Vô","D)Tia"};
		WizardBase tela6 = WizardFactory.createList("Pagina 04", "opt", "5)Qual é o parente que nunca vai se recusar a ir em uma festa?", opcoes5);        
        //Tela07
        WizardBase tela7 = WizardFactory.createText(
                "Resultados","",
                true); // que o texto fica vazio
       
        // Encadeamento
        tela1.nextWizard(tela2);
        tela2.nextWizard(tela3);
        tela3.nextWizard(tela4);
        tela4.nextWizard(tela5);
        tela5.nextWizard(tela6);
        tela6.nextWizard(tela7);
        
        // Pre-Processamento
        tela7.addPreProcessor((wiz) -> tela6PreProcessor(wiz));
        tela7.addPreProcessor((wiz) -> tela5PreProcessor(wiz));
        tela7.addPreProcessor((wiz) -> tela4PreProcessor(wiz));
        tela7.addPreProcessor((wiz) -> tela3PreProcessor(wiz));
        tela7.addPreProcessor((wiz) -> tela2PreProcessor(wiz));
        // Acionamento da aplicação
        SwingUtilities.invokeLater(()->tela1.setVisible(true));
    }
	public static void tela6PreProcessor(WizardBase wizard) {
		
		WizardText wizardText = (WizardText)wizard;
		wizardText.setText("Alternativas Selecionadas:\n\n");
		Data data = Data.instance();
		String[] key = data.keys().toArray(new String[0]);
		Arrays.sort(key);
		for(String k : key) {
			wizardText.append(String.format("%s = %s\n", k, data.get(k)));

		}
	}
        public static void tela5PreProcessor(WizardBase wizard) {
		
		WizardText wizardText = (WizardText)wizard;
		wizardText.setText("Alternativas Selecionadas:\n\n");
		Data data = Data.instance();
		String[] key = data.keys().toArray(new String[0]);
		Arrays.sort(key);
		for(String k : key) {
			wizardText.append(String.format("%s = %s\n", k, data.get(k)));

		}
	}
        public static void tela4PreProcessor(WizardBase wizard) {
		
		WizardText wizardText = (WizardText)wizard;
		wizardText.setText("Alternativas Selecionadas:\n\n");
		Data data = Data.instance();
		String[] key = data.keys().toArray(new String[0]);
		Arrays.sort(key);
		for(String k : key) {
			wizardText.append(String.format("%s = %s\n", k, data.get(k)));

		}
	}
        public static void tela3PreProcessor(WizardBase wizard) {
		
		WizardText wizardText = (WizardText)wizard;
		wizardText.setText("Alternativas Selecionadas:\n\n");
		Data data = Data.instance();
		String[] key = data.keys().toArray(new String[0]);
		Arrays.sort(key);
		for(String k : key) {
			wizardText.append(String.format("%s = %s\n", k, data.get(k)));

		}
	}
        public static void tela2PreProcessor(WizardBase wizard) {
		
		WizardText wizardText = (WizardText)wizard;
		wizardText.setText("Alternativas Selecionadas:\n\n");
		Data data = Data.instance();
		String[] key = data.keys().toArray(new String[0]);
		Arrays.sort(key);
		for(String k : key) {
			wizardText.append(String.format("%s = %s\n", k, data.get(k)));
		}
	}
}

