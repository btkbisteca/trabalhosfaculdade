package jandl.wizard;

public interface Collector {
	public void put(String key, Object value);
}
